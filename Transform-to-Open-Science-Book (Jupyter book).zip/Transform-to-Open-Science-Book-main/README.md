# Transform-to-Open-Science-Book

This repository contains the text that is contained in the TOPS Jupyter Book.
To view the book click [here](https://nasa.github.io/Transform-to-Open-Science-Book/).
 
## How to Contribute
Contribution guidelines can be found [here](./About/CONTRIBUTING.md).

## Our Contributors

The contributor list is currently being regenerated, as some people wished to be removed due to circumstances outside their control that put them at risk. If you are still willing to be listed, please fill in the form, which has been sent to all contributors. Apologies for the inconvenience! If you did not receive the form, please contact us on info@forrt.org