# Logos

This folder contains the logos of organizations participating in the Year of Open Science.
