This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by0sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

Material that is not under CC-BY-SA license is marked with a license for that material.
